package com.cg.hms.exception;

public class HMSException extends Exception{

	private static final long serialVersionUID = 1212121212L;

		public HMSException(String errMsg){
			super(errMsg);
		}
}
