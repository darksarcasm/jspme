package com.cg.hms.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import javax.transaction.Transactional;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Repository;

import com.cg.hms.bean.Hotel;
import com.cg.hms.bean.Room;
import com.cg.hms.exception.HMSException;
import com.cg.hms.util.DbUtil;

@Transactional
@Repository
public class HotelDAOImpl implements IHotelDAO {
	@PersistenceContext
	private EntityManager eManager;

	private Logger log = Logger.getLogger("HotelDAO");
	
	//------------------------ 1. HotelManagementSystem --------------------------
	/*******************************************************************************************************
		- Function Name		:	listHotels
		- Input Parameters	:	-
		- Return Type		:	List hotelList
		- Throws			:  	HMSException
		- Creation Date		:	10/10/2018
		- Description		:	list hotels in the database
	********************************************************************************************************/

	@Override
	public List<Room> listRoom() throws HMSException {
		System.out.println("reached list rooms");
		String sql="SELECT roomdetails from Room roomdetails";
		TypedQuery<Room> qry=eManager.createQuery(sql, Room.class);
		@SuppressWarnings("unchecked")
		List<Room> roomList=qry.getResultList();
		System.out.println(roomList);
		return roomList;
		
	}
	@Override
	public List<Hotel> listHotels() throws HMSException {
		
//		List<Hotel> hotelList;
//		try (Connection conn = DbUtil.getConnection();
//				PreparedStatement st = conn.prepareStatement(IQueryMapper.LIST_HOTELS);) {
//
//			log.info("Retrieve List of Hotels from the Database");
//			ResultSet rs = st.executeQuery();
//
//			hotelList = new ArrayList<Hotel>();
//
//			while (rs.next()) {
//
//				Hotel hotel = new Hotel();
//				hotel.setHotelId(rs.getInt(1));
//				hotel.setCity(rs.getString(2));
//				hotel.setHotelName(rs.getString(3));
//				hotel.setAddress(rs.getString(4));
//				hotel.setDescription(rs.getString(5));
//				hotel.setAvgRatePerNight(rs.getInt(6));
//				hotel.setPhoneNo1(rs.getString(7));
//				hotel.setPhoneNo2(rs.getString(8));
//				hotel.setRating(rs.getString(9));
//				hotel.setEmail(rs.getString(10));
//				hotel.setFax(rs.getString(11));
//
//				hotelList.add(hotel);
//			}
//
//			if (hotelList.size() == 0)
//				hotelList = null;
//		} catch (SQLException e) {
//			log.error("SQL ERROR IN FETCHING HOTEL DATA FROM THE DATABASE");
//			throw new HMSException("Unable To Fetch Hotels");
//		}
//		return hotelList;
		
		System.out.println("reached list hotels");
		String sql="SELECT hotel from Hotel hotel";
		TypedQuery<Hotel> qry=eManager.createQuery(sql, Hotel.class);
		@SuppressWarnings("unchecked")
		List<Hotel> hotelList=qry.getResultList();
		System.out.println(hotelList);
		return hotelList;
	}
	
	//------------------------ 1. HotelManagementSystem --------------------------
	/*******************************************************************************************************
		- Function Name		:	findHotel
		- Input Parameters	:	Integer hcode
		- Return Type		:	Hotel object
		- Throws			:  	HMSException
		- Creation Date		:	10/10/2018
		- Description		:	finding hotel in the database using hotel code
	********************************************************************************************************/	
	

	@Override
	public Hotel findHotel(int hcode) throws HMSException {
		Hotel hotel = null;
		try (Connection conn = DbUtil.getConnection();
				PreparedStatement st = conn.prepareStatement(IQueryMapper.FIND_HOTEL);) {
			st.setInt(1, hcode);
			
			log.info("Finding Hotel in the Database using Hotel code");
			
			ResultSet rs = st.executeQuery();

			if (rs.next()) {
				hotel = new Hotel();
				hotel.setHotelId(rs.getInt(1));
			}

		} catch (SQLException e) {
			log.error("SQL ERROR IN FINDING HOTEL DATA FROM THE DATABASE");
			throw new HMSException("Unable To Fetch Hotel");
		}
		return hotel;

	}

	//------------------------ 1. HotelManagementSystem --------------------------
	/*******************************************************************************************************
		- Function Name		:	listRooms
		- Input Parameters	:	Integer hcode
		- Return Type		:	List roomList
		- Throws			:  	HMSException
		- Creation Date		:	10/10/2018
		- Description		:	list rooms in particular hotel from the database
	********************************************************************************************************/	
	
	@Override
	public List<Room> listRooms(int hcode) throws HMSException {

		List<Room> roomList;
		try (Connection conn = DbUtil.getConnection();
				PreparedStatement st = conn.prepareStatement(IQueryMapper.FIND_ROOMS);) {
			st.setInt(1, hcode);
			ResultSet rs = st.executeQuery();
			roomList = new ArrayList<Room>();
			
			log.info("Retrieving list of Rooms in particular Hotel from the Database");
			
			while (rs.next()) {
				Room room = new Room();
				room.setHotelId(rs.getInt(1));
				room.setRoomId(rs.getInt(2));
				room.setRoomNo(rs.getInt(3));
				room.setRoomType(rs.getString(4));
				room.setPerNightPrice(rs.getDouble(5));
				room.setAvailable(rs.getString(6));
				roomList.add(room);
			}

		} catch (SQLException e) {
			log.error("SQL ERROR IN FETCHING ROOM DATA FROM THE DATABASE");
			throw new HMSException("Unable To Fetch Rooms");
		}
		return roomList;

	}

}
