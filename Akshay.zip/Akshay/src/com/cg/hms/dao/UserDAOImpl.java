package com.cg.hms.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.cg.hms.bean.User;
import com.cg.hms.exception.HMSException;
import com.cg.hms.util.DbUtil;

public class UserDAOImpl implements IUserDAO {

	private Logger log = Logger.getLogger("UserDAO");

	int status = 0;
	int userId = 0;

	public UserDAOImpl() {
		PropertyConfigurator.configure("res//log4j.properties");
	}
	
	//------------------------ 1. HotelManagementSystem --------------------------
	/*******************************************************************************************************
		- Function Name		:	getUserByName
		- Input Parameters	:	String userName
		- Return Type		:	User object
		- Throws			:  	HMSException
		- Creation Date		:	10/10/2018
		- Description		:	fetch user details from the database
	********************************************************************************************************/

	@Override
	public User getUserByName(String userName) throws HMSException {
		User user = null;
		try (Connection con = DbUtil.getConnection();
				PreparedStatement st = con.prepareStatement(IQueryMapper.GET_USER)) {

			st.setString(1, userName);

			log.info("Fetching User Details from the Database");
			
			ResultSet rs = st.executeQuery();
			if (rs.next()) {
				user = new User();
				user.setUserId(rs.getInt(1));
				user.setPassword(rs.getString(2));
				user.setRole(rs.getString(3));
				user.setUserName(rs.getString(4));
			}
		} catch (SQLException e) {
			log.error("SQL ERROR IN FETCHING USER DATA FROM THE DATABASE");
			throw new HMSException("Unable To Fetch Records");
		}
		return user;
	}

	//------------------------ 1. HotelManagementSystem --------------------------
	/*******************************************************************************************************
		- Function Name		:	addUser
		- Input Parameters	:	User object
		- Return Type		:	Integer status
		- Throws			:  	HMSException
		- Creation Date		:	10/10/2018
		- Description		:	add user details to the database
	********************************************************************************************************/	
	
	@Override
	public int addUser(User newUser) throws HMSException {
		// TODO Auto-generated method stub

		Connection conn = null;
		PreparedStatement st = null;
		PreparedStatement st1 = null;

		try {

			conn = DbUtil.getConnection();
			st = conn.prepareStatement(IQueryMapper.INSERT_USER);

			log.info("Adding User Details to the Database");
			
			st.setString(1, newUser.getPassword());
			st.setString(2, newUser.getRole());
			st.setString(3, newUser.getUserName());
			st.setString(4, newUser.getMobileNo());
			st.setString(5, newUser.getPhoneNo());
			st.setString(6, newUser.getAddress());
			st.setString(7, newUser.getEmail());

			status = st.executeUpdate();

			log.info("Fetching User Id from the Sequence");
			st1 = conn.prepareStatement(IQueryMapper.USER_ID_SEQUENCE);
			ResultSet resultSet = st1.executeQuery();

			if (resultSet.next()) {
				userId = resultSet.getInt(1);
			}

			newUser.setUserId(userId);
			
			return status;

		} catch (Exception e) {
			log.error("ERROR IN ADDING USER DATA IN THE DATABASE");
			throw new HMSException("Unable To Add Records");
		} finally {
			try {
				conn.close();
				st.close();
				st1.close();
			} catch (Exception e) {
				log.error("SQL ERROR IN CLOSING CONNECTION");
				throw new HMSException("Check username and Password.");
			}

		}

	}

}
