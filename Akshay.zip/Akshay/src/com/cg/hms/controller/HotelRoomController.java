package com.cg.hms.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.cg.hms.bean.Hotel;
import com.cg.hms.bean.Room;
import com.cg.hms.dao.IHotelDAO;
import com.cg.hms.dao.IRoomDAO;

@Controller
public class HotelRoomController {

	@Autowired
	public IHotelDAO adminService;

	@RequestMapping("/HotelDetails")
	public String showHotelList(Model model) {
		System.out.println("show hotel list");
		List<Hotel> hotelList;
		try{
			
			hotelList=adminService.listHotels();
			model.addAttribute("hotelList", hotelList);
		}
		catch(Exception ex){
			System.out.println("okay exception");
		}
		return "HotelDetails";
	}

	@RequestMapping("/bookinghotelroom")
	public String showHotelBookingForm(@RequestParam("hid") String hid,@RequestParam("hname") String hname,Model model) {

		System.out.println("In booking hotel room");
		List<Room> roomList;
		try{
			System.out.println("In try room");
			roomList=
					adminService.listRoom();
			System.out.println(roomList);
			model.addAttribute("roomList",roomList);
			System.out.println("done2");
		}
		catch(Exception ex){
			System.out.println("okay exception");
		}
//		model.addAttribute("hid",hid);
		return "HotelBooking";
	}

}
