package com.cg.hms.test;

import static org.junit.Assert.assertNotNull;

import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Test;

import com.cg.hms.bean.User;
import com.cg.hms.dao.UserDAOImpl;
import com.cg.hms.exception.HMSException;

public class UserDAOImplTest {

	static UserDAOImpl dao;
	static User user;
	
	@BeforeClass
	public static void initialize() {
		System.out.println("Testing DAO");
		dao = new UserDAOImpl();
		user = new User();
	}
	/*******************************************************
	 * Test case for addUser()
	 *******************************************************/
	@Test
	public void testAddUser() throws HMSException {

		assertNotNull(dao.addUser(user));

	}
	/******************************************************
	 * Test case for Login()
	 ******************************************************/
	@Test
	public void testLogin() throws HMSException {
		assertNotNull(dao.getUserByName("Admin"));
	}
	
	@AfterClass
	public static void destroy() {
		System.out.println("\nTest Ended");
		dao = null;
		user = null;
	}
}
