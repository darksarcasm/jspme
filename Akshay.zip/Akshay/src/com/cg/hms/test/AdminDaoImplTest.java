package com.cg.hms.test;

import static org.junit.Assert.assertNotNull;

import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Test;

import com.cg.hms.bean.Hotel;
import com.cg.hms.dao.AdminDaoImpl;
import com.cg.hms.exception.HMSException;

public class AdminDaoImplTest {

	static AdminDaoImpl dao;
	static Hotel hModify;

	@BeforeClass
	public static void initialize() {
		System.out.println("Testing DAO");
		dao = new AdminDaoImpl();
		hModify = new Hotel();
	}

	/*******************************************************
	 * Test case for ModifyHotel()
	 *******************************************************/
	@Test
	public void testModifyHotel() throws HMSException {

		assertNotNull(dao.modifyHotel(1001, "Modified"));

	}

	@AfterClass
	public static void destroy() {
		System.out.println("\nTest Ended");
		dao = null;
		hModify = null;
	}

}
