package com.cg.hms.ui;

import java.util.Scanner;

import org.apache.log4j.PropertyConfigurator;

import com.cg.hms.bean.User;
import com.cg.hms.exception.HMSException;
import com.cg.hms.service.IUserService;
import com.cg.hms.service.UserServiceImpl;

public class MainUI {

	public static void main(String[] args) {
		System.out.println("Hotel App");

		Scanner scan = new Scanner(System.in);
		PropertyConfigurator.configure("res/log4j.properties");

		int choice = -1;

		int loginAttempts = 0;
		IUserService userService = new UserServiceImpl();
		while (choice != 3 && loginAttempts <= 3) {
			System.out.print("[1]SignUp [2]LogIn [3]Quit >");
			try {
				choice = Integer.parseInt(scan.next());
			} catch (NumberFormatException e) {
				System.err.println("Enter digits (1,2,3) only.");
			}

			if (choice == 1) {

				System.out.println("Welcome to the SignUp Page");
				System.out.print("UserName: ");
				String userName = scan.next();
				System.out.print("Password: ");
				String password = scan.next();
				String role = "Customer";
				System.out.print("Mobile no.: ");
				String mobileNo = scan.next();
				System.out.print("Phone no.: ");
				String phoneNo = scan.next();
				System.out.print("Address: ");
				scan.nextLine();
				String address = scan.nextLine();
				System.out.print("Email ID: xyz@domain.com");
				String email = scan.next();
				int status = 0;

				User newUser = new User(userName, password, role, mobileNo,
						phoneNo, address, email);

				try {
					status = userService.addUser(newUser);

				} catch (HMSException e) {
					System.err.println(e.getMessage());
				}

				if (status > 0) {
					System.out.println("User: " + newUser.getUserName()
							+ " Registered Successfully.\nYour UserID is "
							+ newUser.getUserId());
				}
			}

			if (choice == 2) {
				System.out.print("UserName? ");
				String userName = scan.next();
				System.out.print("Password? ");
				String password = scan.next();
				loginAttempts++;

				try {
					String role = userService.getRole(userName, password);
					if ("admin".equals(role)) {
						AdminConsole ac = new AdminConsole(userName);
						ac.start();
					} else {
						CustomerConsole sc = new CustomerConsole(userName);
						sc.start();
					}
				} catch (HMSException e) {
					System.err.println(e.getMessage());
				}

			}

			if (choice == 3) {
				System.out.println("Logged Out Successfully");
				System.exit(0);
				
			} else {
				System.out.println("Select a valid option");
			}

		}

		scan.close();
	}
}