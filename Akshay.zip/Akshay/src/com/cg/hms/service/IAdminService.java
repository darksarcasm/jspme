package com.cg.hms.service;

import com.cg.hms.bean.Hotel;
import com.cg.hms.bean.Room;
import com.cg.hms.exception.HMSException;

public interface IAdminService {
	public int addHotel(Hotel hotel) throws HMSException;

	public int modifyHotel(int hotelId, String desc) throws HMSException;

	public int deleteHotel(int hotelId) throws HMSException;

	public int addRoom(Room room) throws HMSException;

	public int modifyRoomAvailability(int roomId, String value)
			throws HMSException;

	public int modifyRoomRate(int roomId, int value) throws HMSException;

	public int deleteRoom(int roomId) throws HMSException;

	boolean isValidAddEnquiry(Hotel hotel) throws HMSException;

	boolean isValidDeleteEnquiry(int hotelId) throws HMSException;

	boolean isValidUpdateEnquiry(String desc) throws HMSException;
	public void justTest() throws HMSException;
}
