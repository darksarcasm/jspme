package com.cg.hms.service;

import java.util.List;

import com.cg.hms.bean.Booking;
import com.cg.hms.bean.Room;
import com.cg.hms.exception.HMSException;

public interface IBookingService {

	boolean saveBooking(Booking book) throws HMSException;
	
	public List<Booking> listBookingDetailsByRoomid(int roomid) throws HMSException;

	Room findAmount(int rcode) throws HMSException;

}
