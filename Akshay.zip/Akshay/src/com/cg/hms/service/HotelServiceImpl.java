package com.cg.hms.service;

import java.util.List;

import com.cg.hms.bean.Hotel;
import com.cg.hms.bean.Room;
import com.cg.hms.dao.HotelDAOImpl;
import com.cg.hms.dao.IHotelDAO;
import com.cg.hms.exception.HMSException;

public class HotelServiceImpl implements IHotelService {

	private IHotelDAO hotelDao;

	public HotelServiceImpl() {
		hotelDao = new HotelDAOImpl();
	}

	//------------------------ 1. HotelManagementSystem --------------------------
	/*******************************************************************************************************
		- Function Name		:	listHotels
		- Input Parameters	:	
		- Return Type		:	List hotelList
		- Throws			:  	HMSException
		- Creation Date		:	
		- Description		:	list hotels in the database calls dao method listHotels()
	********************************************************************************************************/
	
	
	@Override
	public List<Hotel> listHotels() throws HMSException {
		List<Hotel> hotelList = null;
		hotelList = hotelDao.listHotels();
		return hotelList;
	}
	
	//------------------------ 1. HotelManagementSystem --------------------------
	/*******************************************************************************************************
		- Function Name		:	findHotel
		- Input Parameters	:	Integer hcode
		- Return Type		:	Hotel object
		- Throws			:  	HMSException
		- Creation Date		:	
		- Description		:	finding hotel in the database using hotel code calls dao method findHotel(hcode)
	********************************************************************************************************/		

	@Override
	public Hotel findHotel(int hcode) throws HMSException {
		Hotel hotel = new Hotel();
		hotel = hotelDao.findHotel(hcode);
		return hotel;
	}

	//------------------------ 1. HotelManagementSystem --------------------------
	/*******************************************************************************************************
		- Function Name		:	listRooms
		- Input Parameters	:	Integer hcode
		- Return Type		:	List roomList
		- Throws			:  	HMSException
		- Creation Date		:	
		- Description		:	list rooms in particular hotel from the database calls dao method listRooms(hcode)
	********************************************************************************************************/		
	
	@Override
	public List<Room> listRooms(int hcode) throws HMSException {
		List<Room> roomList = null; 
		roomList = hotelDao.listRooms(hcode);
		return roomList;
	}

}
